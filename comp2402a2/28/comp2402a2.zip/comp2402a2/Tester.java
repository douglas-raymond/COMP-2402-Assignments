package comp2402a2;

import java.util.List;
import java.util.Queue;

public class Tester {

    public static boolean testPart1(Queue<Integer> q) {
        // Your code goes here
        return false;
    }

    public static boolean testPart2(List<Integer> ad) {
        // Your code goes here
        return false;
    }

    public static boolean testPart3(List<Integer> ad) {
        // Your code goes here
        return false;
    }

    public static boolean testPart5(List<Integer> ras) {
        // Your code goes here
        return false;
    }

}

